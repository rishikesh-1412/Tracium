const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise"); // using promise-based MySQL client

const {processMonthlyJobs} = require("./monthlyProcessing");
const {processHourlyJobs} = require("./hourlyProcessing");
const {processDailyJobs} = require("./dailyProcessing");

const app = express();
const port = 5000;

app.use(express.json());

app.use(cors());

// ---- MySQL connection config ----
const dbConfig = {
  // host: "10.140.98.24", // or your prod DB host
  // user: "datanode_user",
  // password: "09kY3NHs",
  // database: "observium",

  host: "localhost", // or your local DB host
  user: "rishikesh",
  password: "password",
  database: "observium",
};


//api to get mapping of all jobs for specific product
app.get("/datatrail/productMapping/:productName", async (req, res) => {
  const { productName } = req.params;
  const { startDate, endDate } = req.query;

  try {
    const connection = await mysql.createConnection(dbConfig);

    // Query to fetch dependencies dynamically
    const [rows] = await connection.execute(
      `
      SELECT view_name AS view, input_view_name AS input, raw_input
      FROM view_dependencies
      WHERE view_name IN (
        SELECT view_name FROM views WHERE product_name = ?
      )
      `,
      [productName]
    );

    await connection.end();

    res.json({
      productName,
      dependencies: rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch data from database" });
  }
});


// api for getting all available products list
app.get("/datatrail/list/products", async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);

    // Query to fetch distinct product names
    const [rows] = await connection.execute(`
      SELECT DISTINCT product_name
      FROM views
    `);

    await connection.end();

    res.json({
      products: rows
    });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Failed to fetch data from database" });
  }
});


// api for health check of all frequency jobs
app.post("/datatrail/healthCheck/:productName", async (req, res) => {
  const { productName } = req.params;
  const { startDate, endDate } = req.body; // both are in "YYYY-MM-DD-HH"

  try {
    const connection = await mysql.createConnection(dbConfig);

    await connection.query("SET SESSION group_concat_max_len = 1000000");

    // Fetch jobs for the product
    const [jobs] = await connection.execute(
      `SELECT view_name AS jobName, LOWER(frequency) AS frequency
       FROM views
       WHERE product_name = ? AND is_active = 'true'`,
      [productName]
    );

    const dailyJobs = jobs.filter((j) => j.frequency === "daily");
    const hourlyJobs = jobs.filter((j) => j.frequency === "hourly");
    const monthlyJobs = jobs.filter((j) => j.frequency === "monthly");

    const results = [];

    // ---------- DAILY ----------
    if (dailyJobs.length > 0) {
      await processDailyJobs(dailyJobs, startDate, endDate, connection, results);
    }

    // ---------- HOURLY ----------
    if (hourlyJobs.length > 0) {
      await processHourlyJobs(hourlyJobs, startDate, endDate, connection, results);
    }

    // MONTHLY Processing
    if (monthlyJobs.length > 0) {
      await processMonthlyJobs(monthlyJobs, startDate, endDate, connection, results);
    }

    await connection.end();

    res.json({ productName, results });
  } catch (err) {
    console.error("Error in healthCheck:", err);
    res.status(500).json({ error: "Failed to fetch health check" });
  }
});



// Start server
app.listen(port, () => {
  console.log(`DataTrail API running at http://localhost:${port}`);
});
